// $Id: doji.js,v 1.0 2011/10/13 13:25:57 tvazone Exp $
jQuery(document).ready(function() {
  /*
  $('.autosum #edit-doji-chart-price-setting-1d-step').focus(function(){
    min_value = Drupal.doji_gold_price.toNumber($('.autosum #edit-doji-chart-price-setting-1d-min'));
    max_value = Drupal.doji_gold_price.toNumber($('.autosum #edit-doji-chart-price-setting-1d-max'));    
    
    if (min_value > 0 && max_value > 0) {
      step_value = (max_value - min_value)/5;
      $(this).val(step_value);
    }   
  }); 
  $('.autosum #edit-doji-chart-price-setting-3d-step').focus(function(){
    min_value = Drupal.doji_gold_price.toNumber($('.autosum #edit-doji-chart-price-setting-3d-min'));
    max_value = Drupal.doji_gold_price.toNumber($('.autosum #edit-doji-chart-price-setting-3d-max'));    
    
    if (min_value > 0 && max_value > 0) {
      step_value = (max_value - min_value)/5;
      $(this).val(step_value);
    }   
  }); 
  */  
});