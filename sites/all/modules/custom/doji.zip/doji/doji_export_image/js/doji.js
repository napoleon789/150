jQuery(document).ready(function() {
	alert(2324434);
	});